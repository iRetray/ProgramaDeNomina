-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-11-2020 a las 23:36:04
-- Versión del servidor: 10.4.14-MariaDB
-- Versión de PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `nomina`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `employees`
--

CREATE TABLE `employees` (
  `cedula` int(100) NOT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `sueldo` int(100) NOT NULL,
  `dias` int(100) NOT NULL,
  `nhed` int(100) NOT NULL,
  `nhen` int(100) NOT NULL,
  `nhedd` int(100) NOT NULL,
  `nhedn` int(100) NOT NULL,
  `nhrn` int(100) NOT NULL,
  `transporte` int(100) NOT NULL,
  `nhedv` int(100) NOT NULL,
  `nhenv` int(100) NOT NULL,
  `nheddv` int(100) NOT NULL,
  `nhednv` int(100) NOT NULL,
  `nhrnv` int(100) NOT NULL,
  `extras` int(100) NOT NULL,
  `devengado` int(100) NOT NULL,
  `salud` int(100) NOT NULL,
  `pension` int(100) NOT NULL,
  `solidario` int(100) NOT NULL,
  `uvt` int(100) NOT NULL,
  `retefuente` int(100) NOT NULL,
  `deducido` int(100) NOT NULL,
  `neto` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `employees`
--

INSERT INTO `employees` (`cedula`, `nombre`, `sueldo`, `dias`, `nhed`, `nhen`, `nhedd`, `nhedn`, `nhrn`, `transporte`, `nhedv`, `nhenv`, `nheddv`, `nhednv`, `nhrnv`, `extras`, `devengado`, `salud`, `pension`, `solidario`, `uvt`, `retefuente`, `deducido`, `neto`) VALUES
(7654, 'Natalia', 271823123, 15, 2, 3, 4, 2, 1, 102845, 9144, 19203, 29260, 18288, 1280, 77175, 169966620, 10872925, 10872925, 2718231, 7633, 4077347, 28541428, 141425192),
(12345, 'Jose Cruz', 1200000, 24, 2, 2, 2, 2, 2, 102845, 9144, 12802, 14630, 18288, 2560, 57424, 1257424, 48000, 48000, 0, 33, 0, 96000, 1161424),
(712381, 'Esteban', 123123123, 23, 2, 4, 2, 3, 1, 102845, 9144, 25604, 14630, 27432, 1280, 78090, 118071080, 4924925, 4924925, 1231231, 3457, 1846847, 12927928, 105143152);

--
-- Disparadores `employees`
--
DELIMITER $$
CREATE TRIGGER `transporte` BEFORE INSERT ON `employees` FOR EACH ROW BEGIN
    SET NEW.transporte = 102845;
END
$$
DELIMITER ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`cedula`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
