﻿namespace ProgramaDeFactoracion
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.gridDatos = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textCedula = new System.Windows.Forms.TextBox();
            this.buttonAñadir = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cedulaDelete = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.textNombre = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textSueldo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textDias = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textNHED = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textNHEN = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textNHEDD = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textNHEDN = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textNHRN = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.sueldo = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.dias = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.nhed = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.nhen = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.nhedd = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.extras = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.transporte = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.nhrn = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.nhedn = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.solidario = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.pension = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.salud = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.devengado = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.neto = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.deducido = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.retefuente = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.uvt = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.cedulaGet = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.gridDatos)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(111, -12);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(10);
            this.label1.Size = new System.Drawing.Size(637, 86);
            this.label1.TabIndex = 0;
            this.label1.Text = "Programa administrador de Nómina";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.UseWaitCursor = true;
            // 
            // gridDatos
            // 
            this.gridDatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridDatos.Location = new System.Drawing.Point(17, 52);
            this.gridDatos.Name = "gridDatos";
            this.gridDatos.Size = new System.Drawing.Size(775, 232);
            this.gridDatos.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 1);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(10);
            this.label2.Size = new System.Drawing.Size(231, 41);
            this.label2.TabIndex = 2;
            this.label2.Text = "Crear nuevo trabajador";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(66, 42);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(10);
            this.label3.Size = new System.Drawing.Size(105, 39);
            this.label3.TabIndex = 3;
            this.label3.Text = "Cédula";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textCedula
            // 
            this.textCedula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textCedula.Location = new System.Drawing.Point(58, 84);
            this.textCedula.Name = "textCedula";
            this.textCedula.Size = new System.Drawing.Size(122, 26);
            this.textCedula.TabIndex = 4;
            // 
            // buttonAñadir
            // 
            this.buttonAñadir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAñadir.Location = new System.Drawing.Point(288, 213);
            this.buttonAñadir.Name = "buttonAñadir";
            this.buttonAñadir.Size = new System.Drawing.Size(163, 39);
            this.buttonAñadir.TabIndex = 13;
            this.buttonAñadir.Text = "Añadir";
            this.buttonAñadir.UseVisualStyleBackColor = true;
            this.buttonAñadir.Click += new System.EventHandler(this.buttonAñadir_Click);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 8);
            this.label8.Name = "label8";
            this.label8.Padding = new System.Windows.Forms.Padding(10);
            this.label8.Size = new System.Drawing.Size(231, 41);
            this.label8.TabIndex = 14;
            this.label8.Text = "Lista de trabajadores";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(18, 33);
            this.label9.Name = "label9";
            this.label9.Padding = new System.Windows.Forms.Padding(10);
            this.label9.Size = new System.Drawing.Size(221, 41);
            this.label9.TabIndex = 15;
            this.label9.Text = "Obtener trabajador";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cedulaDelete
            // 
            this.cedulaDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cedulaDelete.Location = new System.Drawing.Point(355, 51);
            this.cedulaDelete.Name = "cedulaDelete";
            this.cedulaDelete.Size = new System.Drawing.Size(125, 26);
            this.cedulaDelete.TabIndex = 18;
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(365, 9);
            this.label10.Name = "label10";
            this.label10.Padding = new System.Windows.Forms.Padding(10);
            this.label10.Size = new System.Drawing.Size(105, 39);
            this.label10.TabIndex = 17;
            this.label10.Text = "Cédula:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(407, 40);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(163, 39);
            this.button1.TabIndex = 19;
            this.button1.Text = "Consultar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.buttonConsultar_Click);
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(61, 101);
            this.label11.Name = "label11";
            this.label11.Padding = new System.Windows.Forms.Padding(10);
            this.label11.Size = new System.Drawing.Size(105, 34);
            this.label11.TabIndex = 20;
            this.label11.Text = "Nombre:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // name
            // 
            this.name.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(149, 101);
            this.name.Name = "name";
            this.name.Padding = new System.Windows.Forms.Padding(10);
            this.name.Size = new System.Drawing.Size(211, 34);
            this.name.TabIndex = 21;
            this.name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textNombre
            // 
            this.textNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNombre.Location = new System.Drawing.Point(190, 84);
            this.textNombre.Name = "textNombre";
            this.textNombre.Size = new System.Drawing.Size(211, 26);
            this.textNombre.TabIndex = 31;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(186, 42);
            this.label4.Name = "label4";
            this.label4.Padding = new System.Windows.Forms.Padding(10);
            this.label4.Size = new System.Drawing.Size(216, 39);
            this.label4.TabIndex = 30;
            this.label4.Text = "Nombre";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textSueldo
            // 
            this.textSueldo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSueldo.Location = new System.Drawing.Point(408, 84);
            this.textSueldo.Name = "textSueldo";
            this.textSueldo.Size = new System.Drawing.Size(115, 26);
            this.textSueldo.TabIndex = 33;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(408, 42);
            this.label5.Name = "label5";
            this.label5.Padding = new System.Windows.Forms.Padding(10);
            this.label5.Size = new System.Drawing.Size(105, 39);
            this.label5.TabIndex = 32;
            this.label5.Text = "Sueldo";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textDias
            // 
            this.textDias.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textDias.Location = new System.Drawing.Point(530, 83);
            this.textDias.Name = "textDias";
            this.textDias.Size = new System.Drawing.Size(127, 26);
            this.textDias.TabIndex = 35;
            this.textDias.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(519, 35);
            this.label6.Name = "label6";
            this.label6.Padding = new System.Windows.Forms.Padding(10);
            this.label6.Size = new System.Drawing.Size(148, 45);
            this.label6.TabIndex = 34;
            this.label6.Text = "Días trabajados";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textNHED
            // 
            this.textNHED.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNHED.Location = new System.Drawing.Point(87, 161);
            this.textNHED.Name = "textNHED";
            this.textNHED.Size = new System.Drawing.Size(100, 26);
            this.textNHED.TabIndex = 37;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(66, 113);
            this.label7.Name = "label7";
            this.label7.Padding = new System.Windows.Forms.Padding(10);
            this.label7.Size = new System.Drawing.Size(148, 45);
            this.label7.TabIndex = 36;
            this.label7.Text = "NHED";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textNHEN
            // 
            this.textNHEN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNHEN.Location = new System.Drawing.Point(207, 161);
            this.textNHEN.Name = "textNHEN";
            this.textNHEN.Size = new System.Drawing.Size(100, 26);
            this.textNHEN.TabIndex = 39;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(186, 113);
            this.label15.Name = "label15";
            this.label15.Padding = new System.Windows.Forms.Padding(10);
            this.label15.Size = new System.Drawing.Size(148, 45);
            this.label15.TabIndex = 38;
            this.label15.Text = "NHEN";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textNHEDD
            // 
            this.textNHEDD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNHEDD.Location = new System.Drawing.Point(324, 161);
            this.textNHEDD.Name = "textNHEDD";
            this.textNHEDD.Size = new System.Drawing.Size(100, 26);
            this.textNHEDD.TabIndex = 41;
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(313, 113);
            this.label16.Name = "label16";
            this.label16.Padding = new System.Windows.Forms.Padding(10);
            this.label16.Size = new System.Drawing.Size(138, 45);
            this.label16.TabIndex = 40;
            this.label16.Text = "NHEDD";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textNHEDN
            // 
            this.textNHEDN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNHEDN.Location = new System.Drawing.Point(437, 161);
            this.textNHEDN.Name = "textNHEDN";
            this.textNHEDN.Size = new System.Drawing.Size(100, 26);
            this.textNHEDN.TabIndex = 43;
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(430, 113);
            this.label18.Name = "label18";
            this.label18.Padding = new System.Windows.Forms.Padding(10);
            this.label18.Size = new System.Drawing.Size(115, 45);
            this.label18.TabIndex = 42;
            this.label18.Text = "NHEDN";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textNHRN
            // 
            this.textNHRN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNHRN.Location = new System.Drawing.Point(551, 161);
            this.textNHRN.Name = "textNHRN";
            this.textNHRN.Size = new System.Drawing.Size(100, 26);
            this.textNHRN.TabIndex = 45;
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(551, 113);
            this.label21.Name = "label21";
            this.label21.Padding = new System.Windows.Forms.Padding(10);
            this.label21.Size = new System.Drawing.Size(100, 45);
            this.label21.TabIndex = 44;
            this.label21.Text = "NHRN";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sueldo
            // 
            this.sueldo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sueldo.Location = new System.Drawing.Point(152, 135);
            this.sueldo.Name = "sueldo";
            this.sueldo.Padding = new System.Windows.Forms.Padding(10);
            this.sueldo.Size = new System.Drawing.Size(208, 34);
            this.sueldo.TabIndex = 47;
            this.sueldo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(61, 135);
            this.label13.Name = "label13";
            this.label13.Padding = new System.Windows.Forms.Padding(10);
            this.label13.Size = new System.Drawing.Size(105, 34);
            this.label13.TabIndex = 46;
            this.label13.Text = "Sueldo:";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dias
            // 
            this.dias.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dias.Location = new System.Drawing.Point(188, 169);
            this.dias.Name = "dias";
            this.dias.Padding = new System.Windows.Forms.Padding(10);
            this.dias.Size = new System.Drawing.Size(172, 34);
            this.dias.TabIndex = 49;
            this.dias.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(52, 163);
            this.label14.Name = "label14";
            this.label14.Padding = new System.Windows.Forms.Padding(10);
            this.label14.Size = new System.Drawing.Size(147, 46);
            this.label14.TabIndex = 48;
            this.label14.Text = "Dias trabajados:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nhed
            // 
            this.nhed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nhed.Location = new System.Drawing.Point(179, 203);
            this.nhed.Name = "nhed";
            this.nhed.Padding = new System.Windows.Forms.Padding(10);
            this.nhed.Size = new System.Drawing.Size(166, 34);
            this.nhed.TabIndex = 51;
            this.nhed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(52, 203);
            this.label23.Name = "label23";
            this.label23.Padding = new System.Windows.Forms.Padding(10);
            this.label23.Size = new System.Drawing.Size(147, 34);
            this.label23.TabIndex = 50;
            this.label23.Text = "NHED Valor:";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nhen
            // 
            this.nhen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nhen.Location = new System.Drawing.Point(176, 237);
            this.nhen.Name = "nhen";
            this.nhen.Padding = new System.Windows.Forms.Padding(10);
            this.nhen.Size = new System.Drawing.Size(184, 34);
            this.nhen.TabIndex = 53;
            this.nhen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(52, 237);
            this.label22.Name = "label22";
            this.label22.Padding = new System.Windows.Forms.Padding(10);
            this.label22.Size = new System.Drawing.Size(147, 34);
            this.label22.TabIndex = 52;
            this.label22.Text = "NHEN Valor:";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nhedd
            // 
            this.nhedd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nhedd.Location = new System.Drawing.Point(182, 271);
            this.nhedd.Name = "nhedd";
            this.nhedd.Padding = new System.Windows.Forms.Padding(10);
            this.nhedd.Size = new System.Drawing.Size(163, 34);
            this.nhedd.TabIndex = 55;
            this.nhedd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(52, 271);
            this.label24.Name = "label24";
            this.label24.Padding = new System.Windows.Forms.Padding(10);
            this.label24.Size = new System.Drawing.Size(147, 34);
            this.label24.TabIndex = 54;
            this.label24.Text = "NHEDD Valor:";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // extras
            // 
            this.extras.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extras.Location = new System.Drawing.Point(179, 410);
            this.extras.Name = "extras";
            this.extras.Padding = new System.Windows.Forms.Padding(10);
            this.extras.Size = new System.Drawing.Size(166, 34);
            this.extras.TabIndex = 63;
            this.extras.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(52, 410);
            this.label17.Name = "label17";
            this.label17.Padding = new System.Windows.Forms.Padding(10);
            this.label17.Size = new System.Drawing.Size(147, 34);
            this.label17.TabIndex = 62;
            this.label17.Text = "Total Extras:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // transporte
            // 
            this.transporte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transporte.Location = new System.Drawing.Point(179, 376);
            this.transporte.Name = "transporte";
            this.transporte.Padding = new System.Windows.Forms.Padding(10);
            this.transporte.Size = new System.Drawing.Size(166, 34);
            this.transporte.TabIndex = 61;
            this.transporte.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(52, 376);
            this.label20.Name = "label20";
            this.label20.Padding = new System.Windows.Forms.Padding(10);
            this.label20.Size = new System.Drawing.Size(147, 42);
            this.label20.TabIndex = 60;
            this.label20.Text = "Transporte:";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nhrn
            // 
            this.nhrn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nhrn.Location = new System.Drawing.Point(179, 342);
            this.nhrn.Name = "nhrn";
            this.nhrn.Padding = new System.Windows.Forms.Padding(10);
            this.nhrn.Size = new System.Drawing.Size(166, 34);
            this.nhrn.TabIndex = 59;
            this.nhrn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(52, 342);
            this.label26.Name = "label26";
            this.label26.Padding = new System.Windows.Forms.Padding(10);
            this.label26.Size = new System.Drawing.Size(147, 34);
            this.label26.TabIndex = 58;
            this.label26.Text = "NHRN Valor:";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nhedn
            // 
            this.nhedn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nhedn.Location = new System.Drawing.Point(179, 308);
            this.nhedn.Name = "nhedn";
            this.nhedn.Padding = new System.Windows.Forms.Padding(10);
            this.nhedn.Size = new System.Drawing.Size(166, 34);
            this.nhedn.TabIndex = 57;
            this.nhedn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(52, 302);
            this.label28.Name = "label28";
            this.label28.Padding = new System.Windows.Forms.Padding(10);
            this.label28.Size = new System.Drawing.Size(147, 46);
            this.label28.TabIndex = 56;
            this.label28.Text = "NHEDN Valor:";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // solidario
            // 
            this.solidario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.solidario.Location = new System.Drawing.Point(480, 209);
            this.solidario.Name = "solidario";
            this.solidario.Padding = new System.Windows.Forms.Padding(10);
            this.solidario.Size = new System.Drawing.Size(119, 34);
            this.solidario.TabIndex = 71;
            this.solidario.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(341, 209);
            this.label30.Name = "label30";
            this.label30.Padding = new System.Windows.Forms.Padding(10);
            this.label30.Size = new System.Drawing.Size(147, 34);
            this.label30.TabIndex = 70;
            this.label30.Text = "Fondo solidario:";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pension
            // 
            this.pension.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pension.Location = new System.Drawing.Point(449, 175);
            this.pension.Name = "pension";
            this.pension.Padding = new System.Windows.Forms.Padding(10);
            this.pension.Size = new System.Drawing.Size(150, 34);
            this.pension.TabIndex = 69;
            this.pension.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(341, 175);
            this.label32.Name = "label32";
            this.label32.Padding = new System.Windows.Forms.Padding(10);
            this.label32.Size = new System.Drawing.Size(147, 34);
            this.label32.TabIndex = 68;
            this.label32.Text = "Pension:";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // salud
            // 
            this.salud.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salud.Location = new System.Drawing.Point(446, 141);
            this.salud.Name = "salud";
            this.salud.Padding = new System.Windows.Forms.Padding(10);
            this.salud.Size = new System.Drawing.Size(153, 34);
            this.salud.TabIndex = 67;
            this.salud.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(341, 141);
            this.label34.Name = "label34";
            this.label34.Padding = new System.Windows.Forms.Padding(10);
            this.label34.Size = new System.Drawing.Size(147, 34);
            this.label34.TabIndex = 66;
            this.label34.Text = "Salud:";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // devengado
            // 
            this.devengado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.devengado.Location = new System.Drawing.Point(465, 107);
            this.devengado.Name = "devengado";
            this.devengado.Padding = new System.Windows.Forms.Padding(10);
            this.devengado.Size = new System.Drawing.Size(134, 34);
            this.devengado.TabIndex = 65;
            this.devengado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(341, 101);
            this.label36.Name = "label36";
            this.label36.Padding = new System.Windows.Forms.Padding(10);
            this.label36.Size = new System.Drawing.Size(147, 46);
            this.label36.TabIndex = 64;
            this.label36.Text = "Devengado:";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // neto
            // 
            this.neto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.neto.Location = new System.Drawing.Point(449, 345);
            this.neto.Name = "neto";
            this.neto.Padding = new System.Windows.Forms.Padding(10);
            this.neto.Size = new System.Drawing.Size(150, 34);
            this.neto.TabIndex = 79;
            this.neto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(341, 345);
            this.label38.Name = "label38";
            this.label38.Padding = new System.Windows.Forms.Padding(10);
            this.label38.Size = new System.Drawing.Size(147, 34);
            this.label38.TabIndex = 78;
            this.label38.Text = "Neto:";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // deducido
            // 
            this.deducido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deducido.Location = new System.Drawing.Point(483, 311);
            this.deducido.Name = "deducido";
            this.deducido.Padding = new System.Windows.Forms.Padding(10);
            this.deducido.Size = new System.Drawing.Size(116, 34);
            this.deducido.TabIndex = 77;
            this.deducido.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(341, 311);
            this.label40.Name = "label40";
            this.label40.Padding = new System.Windows.Forms.Padding(10);
            this.label40.Size = new System.Drawing.Size(147, 34);
            this.label40.TabIndex = 76;
            this.label40.Text = "Total deducido:";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // retefuente
            // 
            this.retefuente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.retefuente.Location = new System.Drawing.Point(468, 277);
            this.retefuente.Name = "retefuente";
            this.retefuente.Padding = new System.Windows.Forms.Padding(10);
            this.retefuente.Size = new System.Drawing.Size(131, 34);
            this.retefuente.TabIndex = 75;
            this.retefuente.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(341, 277);
            this.label42.Name = "label42";
            this.label42.Padding = new System.Windows.Forms.Padding(10);
            this.label42.Size = new System.Drawing.Size(147, 34);
            this.label42.TabIndex = 74;
            this.label42.Text = "Retefuente:";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uvt
            // 
            this.uvt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uvt.Location = new System.Drawing.Point(449, 243);
            this.uvt.Name = "uvt";
            this.uvt.Padding = new System.Windows.Forms.Padding(10);
            this.uvt.Size = new System.Drawing.Size(150, 34);
            this.uvt.TabIndex = 73;
            this.uvt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(341, 237);
            this.label44.Name = "label44";
            this.label44.Padding = new System.Windows.Forms.Padding(10);
            this.label44.Size = new System.Drawing.Size(147, 46);
            this.label44.TabIndex = 72;
            this.label44.Text = "UVT:";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label45
            // 
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(104, 36);
            this.label45.Name = "label45";
            this.label45.Padding = new System.Windows.Forms.Padding(10);
            this.label45.Size = new System.Drawing.Size(231, 41);
            this.label45.TabIndex = 80;
            this.label45.Text = "Eliminar trabajador";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(237, 102);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(163, 39);
            this.button2.TabIndex = 81;
            this.button2.Text = "Eliminar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.buttonEliminar_Click);
            // 
            // cedulaGet
            // 
            this.cedulaGet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cedulaGet.Location = new System.Drawing.Point(245, 57);
            this.cedulaGet.Name = "cedulaGet";
            this.cedulaGet.Size = new System.Drawing.Size(125, 26);
            this.cedulaGet.TabIndex = 83;
            // 
            // label46
            // 
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(255, 15);
            this.label46.Name = "label46";
            this.label46.Padding = new System.Windows.Forms.Padding(10);
            this.label46.Size = new System.Drawing.Size(105, 39);
            this.label46.TabIndex = 82;
            this.label46.Text = "Cédula:";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.gridDatos);
            this.panel1.Location = new System.Drawing.Point(12, 66);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(811, 307);
            this.panel1.TabIndex = 84;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.textCedula);
            this.panel2.Controls.Add(this.buttonAñadir);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.textNombre);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.textSueldo);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.textDias);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.textNHED);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.textNHEN);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.textNHEDD);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.textNHEDN);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.textNHRN);
            this.panel2.Location = new System.Drawing.Point(12, 383);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(811, 269);
            this.panel2.TabIndex = 85;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel3.Controls.Add(this.label45);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.cedulaDelete);
            this.panel3.Controls.Add(this.button2);
            this.panel3.Location = new System.Drawing.Point(829, 496);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(632, 156);
            this.panel3.TabIndex = 86;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel4.Controls.Add(this.label46);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.button1);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.cedulaGet);
            this.panel4.Controls.Add(this.name);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.neto);
            this.panel4.Controls.Add(this.sueldo);
            this.panel4.Controls.Add(this.label38);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.deducido);
            this.panel4.Controls.Add(this.dias);
            this.panel4.Controls.Add(this.label40);
            this.panel4.Controls.Add(this.label23);
            this.panel4.Controls.Add(this.retefuente);
            this.panel4.Controls.Add(this.nhed);
            this.panel4.Controls.Add(this.label42);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.uvt);
            this.panel4.Controls.Add(this.nhen);
            this.panel4.Controls.Add(this.label44);
            this.panel4.Controls.Add(this.label24);
            this.panel4.Controls.Add(this.solidario);
            this.panel4.Controls.Add(this.nhedd);
            this.panel4.Controls.Add(this.label30);
            this.panel4.Controls.Add(this.label28);
            this.panel4.Controls.Add(this.pension);
            this.panel4.Controls.Add(this.nhedn);
            this.panel4.Controls.Add(this.label32);
            this.panel4.Controls.Add(this.label26);
            this.panel4.Controls.Add(this.salud);
            this.panel4.Controls.Add(this.nhrn);
            this.panel4.Controls.Add(this.label34);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.devengado);
            this.panel4.Controls.Add(this.transporte);
            this.panel4.Controls.Add(this.label36);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.extras);
            this.panel4.Location = new System.Drawing.Point(829, 12);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(632, 478);
            this.panel4.TabIndex = 87;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1473, 664);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.gridDatos)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView gridDatos;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textCedula;
        private System.Windows.Forms.Button buttonAñadir;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox cedulaDelete;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.TextBox textNombre;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textSueldo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textDias;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textNHED;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textNHEN;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textNHEDD;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textNHEDN;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textNHRN;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label sueldo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label dias;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label nhed;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label nhen;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label nhedd;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label extras;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label transporte;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label nhrn;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label nhedn;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label solidario;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label pension;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label salud;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label devengado;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label neto;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label deducido;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label retefuente;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label uvt;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox cedulaGet;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
    }
}

